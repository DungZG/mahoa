import React, { useState } from 'react';

const caesarCipher = (str, shift) => {
    return str.replace(/[a-zA-Z]/g, (c) => {
        const base = c >= 'a' ? 97 : 65;
        return String.fromCharCode(((c.charCodeAt(0) - base + shift) % 26) + base);
    });
};

const caesarDecipher = (str, shift) => {
    return caesarCipher(str, -shift);
};

const CaesarCipher = () => {
    const [input, setInput] = useState('');
    const [shift, setShift] = useState(3);
    const [output, setOutput] = useState('');

    const handleEncrypt = () => {
        setOutput(caesarCipher(input, shift));
    };

    const handleDecrypt = () => {
        setOutput(caesarDecipher(input, shift));
    };

    return (
        <div className="mb-4">
            <h2 className="text-xl font-semibold mb-2">Caesar Cipher</h2>
            <input
                type="text"
                placeholder="Enter text"
                className="border p-2 w-full mb-2"
                value={input}
                onChange={(e) => setInput(e.target.value)}
            />
            <input
                type="number"
                placeholder="Shift value"
                className="border p-2 w-full mb-2"
                value={shift}
                onChange={(e) => setShift(Number(e.target.value))}
            />
            <div className="flex gap-2">
                <button className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600" onClick={handleEncrypt}>
                    Mã Hóa
                </button>
                <button className="bg-red-500 text-white py-2 px-4 rounded hover:bg-red-600" onClick={handleDecrypt}>
                    Giải Mã
                </button>
            </div>
            <div className="mt-4">
                <h3 className="text-lg font-semibold">Output:</h3>
                <p className="p-2 bg-gray-100 rounded">{output}</p>
            </div>
        </div>
    );
};

export default CaesarCipher;
