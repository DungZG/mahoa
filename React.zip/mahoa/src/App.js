import React from 'react';
import CaesarCipher from './components/CaesarCipher';


const App = () => {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center">
      <div className="bg-white shadow-lg rounded-lg p-6 w-full max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-center">7 Thuật Toán Mã Hóa</h1>
        <CaesarCipher />
      </div>
    </div>
  );
};

export default App;
